<?php
/**
 * The template for displaying Achive(s)tags
 *
 */
	get_template_part("archive", "page");
?>