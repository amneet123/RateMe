jQuery(document).ready(function($) {
	$('.background-video').wallpaper();
});
