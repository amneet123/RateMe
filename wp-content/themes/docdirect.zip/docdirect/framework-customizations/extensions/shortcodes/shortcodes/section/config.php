<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'tab'         => esc_html__('Layout Elements', 'docdirect'),
		'title'       => esc_html__('Section', 'docdirect'),
		'description' => esc_html__('Add a Section', 'docdirect'),
		'type'        => 'section' // WARNING: Do not edit this
	)
);